<?php

return [
    'read_only' => 'Application en mode lecture seule.',
];
