<?php

return [
    'read_only' => 'Application is on read only mode.',
];
