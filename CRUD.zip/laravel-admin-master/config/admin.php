<?php

return [
    'url' => env('ADMIN_URL', 'http://localhost:8080'),
    'read_only' => env('ADMIN_READ_ONLY', false),
];
